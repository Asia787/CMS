# College Management System

**DBMS Course Project (COMP-351)**  
**Student:** Asia Younus  
**Roll No:** BSM5-25-13  
**Submitted to:** Dr. Imran Javaid

A database-backed College Management System using React.js, Python FastAPI, PostgreSQL, SQLAlchemy, Pydantic and Alembic.

## Features
- Dashboard counts for students, faculty, courses, departments, attendance and pending invoices.
- Department, student, teacher, academic session, course and course-offering management.
- Course registration (student-to-course M:N relationship resolved through registration table).
- Attendance, assessments, marks/results, fee invoices and payments.
- JWT login, first-admin setup, role field, Admin-only deletion and user creation.
- Pydantic request validation, PostgreSQL constraints and Alembic schema migration.
- Optional import of existing SQLite students/teachers.

## Architecture
Browser (React) → HTTP/JSON → FastAPI → Pydantic validation → SQLAlchemy ORM → PostgreSQL → JSON response → React UI.

## Requirements
Python 3.11+, Node.js 20+, PostgreSQL 14+.

## 1. Create PostgreSQL database
Open pgAdmin or psql and run:

```sql
CREATE DATABASE college_management;
```

## 2. Start backend (Windows PowerShell)

```powershell
cd backend
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
copy .env.example .env
```

Edit `backend/.env` and set your PostgreSQL password and a long random `SECRET_KEY`. Then:

```powershell
alembic upgrade head
uvicorn app.main:app --reload
```

API documentation: http://localhost:8000/docs

## 3. Start React frontend
Open a second terminal:

```powershell
cd frontend
copy .env.example .env
npm install
npm run dev
```

Open http://localhost:5173. On first visit use **Create the initial admin account**, choose a password of at least 8 characters, then sign in.

## 4. Existing SQLite project migration
The previous project files were reviewed. The old `app.py` had a malformed table-creation block, routes referenced a mismatched attendance filename, and most HTML forms only displayed success messages without saving records. `database.py` created only students and teachers in SQLite. The new React forms submit real API requests and store records in PostgreSQL.

Your old `college.db` currently contains empty `students` and `teachers` tables. If you later add old records, copy `college.db` into the project root and run from `backend`:

```powershell
$env:LEGACY_SQLITE_PATH="../college.db"
python migrate_legacy_sqlite.py
```

This imports student and teacher rows; it does not copy old HTML-only attendance/fee/result messages because those forms never stored records.

## Main database tables
`departments`, `students`, `teachers`, `academic_sessions`, `courses`, `course_offerings`, `course_registrations`, `attendance`, `assessments`, `assessment_results`, `fee_invoices`, `payments`, `users`.

## Useful SQL for demo / viva

```sql
SELECT * FROM students;
SELECT s.roll_number, s.name, d.name AS department
FROM students s LEFT JOIN departments d ON d.id = s.department_id;
SELECT s.name, c.title AS course, r.status
FROM course_registrations r
JOIN students s ON s.id = r.student_id
JOIN course_offerings o ON o.id = r.offering_id
JOIN courses c ON c.id = o.course_id;
```

## Notes
- Alembic manages schema changes. `Base.metadata.create_all()` is retained as a local first-run fallback.
- This is a course-project starter, not a production deployment. Before public hosting, add password reset, stronger role policies, HTTPS, backups, rate limits and managed PostgreSQL.
- GitHub Pages cannot run FastAPI or PostgreSQL. Deploy React and API separately (e.g. static frontend + Python API host + managed PostgreSQL).
