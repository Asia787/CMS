"""Optional one-time import of old college.db students/teachers into PostgreSQL.
Run from backend after configuring .env and applying migrations.
"""
import sqlite3, os
from sqlalchemy import select
from app.database import SessionLocal
from app.models import Department, Student, Teacher
SOURCE=os.getenv('LEGACY_SQLITE_PATH','../college.db')
old=sqlite3.connect(SOURCE); old.row_factory=sqlite3.Row; db=SessionLocal()
try:
    dept_cache={}
    def dept_id(name):
        if not name: return None
        if name not in dept_cache:
            code=''.join(x[0] for x in name.split()).upper()[:10] or 'GEN'
            existing=db.scalar(select(Department).where(Department.name==name))
            if not existing:
                existing=Department(name=name,code=code); db.add(existing); db.flush()
            dept_cache[name]=existing.id
        return dept_cache[name]
    for row in old.execute('select * from students'):
        roll=row['roll_number'] if 'roll_number' in row.keys() else f"LEGACY-{row['id']}"
        if not db.scalar(select(Student).where(Student.roll_number==roll)):
            db.add(Student(roll_number=roll,name=row['name'],email=row['email'],phone=row['phone'],department_id=dept_id(row['department'])))
    for row in old.execute('select * from teachers'):
        if not db.scalar(select(Teacher).where(Teacher.email==row['email'])) if row['email'] else True:
            db.add(Teacher(name=row['name'],email=row['email'],phone=row['phone'],department_id=dept_id(row['department'])))
    db.commit(); print('Legacy records imported successfully.')
finally: db.close(); old.close()
