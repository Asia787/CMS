from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from sqlalchemy import select, func
from .database import Base, engine, get_db, settings
from . import models as m, schemas as s
from .security import hash_password, verify_password, create_token, current_user, admin_user

app=FastAPI(title='College Management System API',version='1.0.0',description='DBMS course project: React + FastAPI + PostgreSQL')
app.add_middleware(CORSMiddleware,allow_origins=[settings.frontend_origin,'http://localhost:5173'],allow_credentials=True,allow_methods=['*'],allow_headers=['*'])
# Alembic owns production schema changes. This fallback helps a fresh local demo start.
@app.on_event('startup')
def startup(): Base.metadata.create_all(bind=engine)
@app.get('/')
def root(): return {'message':'College Management System API','docs':'/docs','health':'/api/health'}
@app.get('/api/health')
def health(db:Session=Depends(get_db)): return {'status':'ok','database':'connected','students':db.scalar(select(func.count()).select_from(m.Student))}
@app.post('/api/auth/setup-admin')
def setup_admin(payload:s.LoginIn,db:Session=Depends(get_db)):
    if db.scalar(select(func.count()).select_from(m.User)): raise HTTPException(403,'Initial admin already exists; sign in instead')
    user=m.User(username=payload.username,password_hash=hash_password(payload.password),role='Admin'); db.add(user); db.commit(); return {'message':'Admin account created. Sign in now.'}
@app.post('/api/auth/login')
def login(payload:s.LoginIn,db:Session=Depends(get_db)):
    user=db.scalar(select(m.User).where(m.User.username==payload.username))
    if not user or not verify_password(payload.password,user.password_hash): raise HTTPException(401,'Incorrect username or password')
    return {'access_token':create_token(user),'token_type':'bearer','user':{'username':user.username,'role':user.role}}
@app.get('/api/auth/me')
def me(user:m.User=Depends(current_user)): return {'username':user.username,'role':user.role}
@app.post('/api/auth/users',response_model=s.UserOut)
def create_user(payload:s.UserCreate,db:Session=Depends(get_db),_:m.User=Depends(admin_user)):
    if db.scalar(select(m.User).where(m.User.username==payload.username)): raise HTTPException(409,'Username already exists')
    user=m.User(username=payload.username,password_hash=hash_password(payload.password),role=payload.role); db.add(user); db.commit(); db.refresh(user); return user

RESOURCES={
'departments':(m.Department,s.DepartmentIn,s.DepartmentOut), 'guardians':(m.Guardian,s.GuardianIn,s.GuardianOut), 'student-guardians':(m.StudentGuardian,s.StudentGuardianIn,s.StudentGuardianOut), 'grades':(m.Grade,s.GradeIn,s.GradeOut), 'sections':(m.Section,s.SectionIn,s.SectionOut), 'teaching-assignments':(m.TeachingAssignment,s.TeachingAssignmentIn,s.TeachingAssignmentOut), 'fee-structures':(m.FeeStructure,s.FeeStructureIn,s.FeeStructureOut), 'invoice-items':(m.InvoiceItem,s.InvoiceItemIn,s.InvoiceItemOut), 'students':(m.Student,s.StudentIn,s.StudentOut), 'teachers':(m.Teacher,s.TeacherIn,s.TeacherOut), 'sessions':(m.AcademicSession,s.SessionIn,s.SessionOut), 'courses':(m.Course,s.CourseIn,s.CourseOut), 'offerings':(m.CourseOffering,s.OfferingIn,s.OfferingOut), 'registrations':(m.CourseRegistration,s.RegistrationIn,s.RegistrationOut), 'attendance':(m.Attendance,s.AttendanceIn,s.AttendanceOut), 'assessments':(m.Assessment,s.AssessmentIn,s.AssessmentOut), 'results':(m.AssessmentResult,s.ResultIn,s.ResultOut), 'invoices':(m.FeeInvoice,s.InvoiceIn,s.InvoiceOut), 'payments':(m.Payment,s.PaymentIn,s.PaymentOut)}
# Explicit route factory keeps validation and CRUD behavior consistent for all modules.
def install_resource(name,model,input_schema,output_schema):
    def listing(db:Session=Depends(get_db),_:m.User=Depends(current_user)):
        return db.scalars(select(model).order_by(model.id.desc()).limit(500)).all()
    def create(payload:input_schema,db:Session=Depends(get_db),_:m.User=Depends(current_user)):
        data=payload.model_dump()
        if model is m.AssessmentResult:
            assessment=db.get(m.Assessment,data['assessment_id'])
            if not assessment: raise HTTPException(404,'Assessment not found')
            if data['obtained_marks']>float(assessment.total_marks): raise HTTPException(422,'Obtained marks cannot exceed total marks')
        obj=model(**data); db.add(obj)
        try: db.commit(); db.refresh(obj)
        except Exception as e: db.rollback(); raise HTTPException(409,'Could not save record. Check duplicate values and foreign keys.') from e
        return obj
    def update(item_id:int,payload:input_schema,db:Session=Depends(get_db),_:m.User=Depends(current_user)):
        obj=db.get(model,item_id)
        if not obj: raise HTTPException(404,'Record not found')
        for key,value in payload.model_dump().items(): setattr(obj,key,value)
        try: db.commit(); db.refresh(obj)
        except Exception as e: db.rollback(); raise HTTPException(409,'Could not update record; check constraints.') from e
        return obj
    def delete(item_id:int,db:Session=Depends(get_db),_:m.User=Depends(admin_user)):
        obj=db.get(model,item_id)
        if not obj: raise HTTPException(404,'Record not found')
        db.delete(obj); db.commit(); return {'message':'Record deleted'}
    listing.__name__=f'list_{name}'; create.__name__=f'create_{name}'; update.__name__=f'update_{name}'; delete.__name__=f'delete_{name}'
    app.get(f'/api/{name}',response_model=list[output_schema],tags=[name])(listing)
    app.post(f'/api/{name}',response_model=output_schema,status_code=201,tags=[name])(create)
    app.put(f'/api/{name}/{{item_id}}',response_model=output_schema,tags=[name])(update)
    app.delete(f'/api/{name}/{{item_id}}',tags=[name])(delete)
for args in RESOURCES.values():
    # tuple contains model, input schema, output schema; key is supplied separately below
    pass
for name,args in RESOURCES.items(): install_resource(name,*args)
@app.get('/api/dashboard',tags=['reports'])
def dashboard(db:Session=Depends(get_db),_:m.User=Depends(current_user)):
    count=lambda model: db.scalar(select(func.count()).select_from(model)) or 0
    return {'students':count(m.Student),'teachers':count(m.Teacher),'courses':count(m.Course),'departments':count(m.Department),'attendance_records':count(m.Attendance),'pending_invoices':db.scalar(select(func.count()).select_from(m.FeeInvoice).where(m.FeeInvoice.status=='Pending')) or 0}
