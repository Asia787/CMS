from datetime import datetime, timedelta, timezone
from jose import jwt, JWTError
from passlib.context import CryptContext
from fastapi import Depends, HTTPException
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session
from .database import settings, get_db
from .models import User
pwd=CryptContext(schemes=['bcrypt'],deprecated='auto')
oauth=OAuth2PasswordBearer(tokenUrl='/api/auth/login')
def hash_password(password:str)->str: return pwd.hash(password)
def verify_password(password:str,hashed:str)->bool: return pwd.verify(password,hashed)
def create_token(user:User):
    exp=datetime.now(timezone.utc)+timedelta(minutes=settings.access_token_minutes)
    return jwt.encode({'sub':str(user.id),'role':user.role,'exp':exp},settings.secret_key,algorithm='HS256')
def current_user(token:str=Depends(oauth),db:Session=Depends(get_db)):
    try: uid=int(jwt.decode(token,settings.secret_key,algorithms=['HS256'])['sub'])
    except (JWTError,ValueError,KeyError): raise HTTPException(401,'Invalid or expired access token')
    user=db.get(User,uid)
    if not user or not user.is_active: raise HTTPException(401,'Inactive user')
    return user
def admin_user(user:User=Depends(current_user)):
    if user.role!='Admin': raise HTTPException(403,'Administrator permission required')
    return user
