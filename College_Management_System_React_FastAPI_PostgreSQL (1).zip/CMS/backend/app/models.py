from datetime import date, datetime
from sqlalchemy import String, Integer, Date, DateTime, ForeignKey, Numeric, Boolean, UniqueConstraint, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship
from .database import Base

class Department(Base):
    __tablename__='departments'
    id: Mapped[int]=mapped_column(primary_key=True)
    name: Mapped[str]=mapped_column(String(120), unique=True, nullable=False)
    code: Mapped[str]=mapped_column(String(20), unique=True, nullable=False)
    description: Mapped[str|None]=mapped_column(Text)
    students=relationship('Student', back_populates='department')
    teachers=relationship('Teacher', back_populates='department')
    courses=relationship('Course', back_populates='department')

class Student(Base):
    __tablename__='students'
    id: Mapped[int]=mapped_column(primary_key=True)
    roll_number: Mapped[str]=mapped_column(String(30), unique=True, index=True)
    name: Mapped[str]=mapped_column(String(120), nullable=False)
    father_name: Mapped[str|None]=mapped_column(String(120))
    email: Mapped[str|None]=mapped_column(String(160), unique=True)
    phone: Mapped[str|None]=mapped_column(String(30))
    date_of_birth: Mapped[date|None]=mapped_column(Date)
    department_id: Mapped[int|None]=mapped_column(ForeignKey('departments.id', ondelete='SET NULL'))
    program: Mapped[str|None]=mapped_column(String(100))
    status: Mapped[str]=mapped_column(String(20), default='Active')
    department=relationship('Department', back_populates='students')
    registrations=relationship('CourseRegistration', back_populates='student')

class Teacher(Base):
    __tablename__='teachers'
    id: Mapped[int]=mapped_column(primary_key=True)
    name: Mapped[str]=mapped_column(String(120), nullable=False)
    email: Mapped[str|None]=mapped_column(String(160), unique=True)
    phone: Mapped[str|None]=mapped_column(String(30))
    designation: Mapped[str|None]=mapped_column(String(100))
    department_id: Mapped[int|None]=mapped_column(ForeignKey('departments.id', ondelete='SET NULL'))
    department=relationship('Department', back_populates='teachers')

class AcademicSession(Base):
    __tablename__='academic_sessions'
    id: Mapped[int]=mapped_column(primary_key=True)
    title: Mapped[str]=mapped_column(String(80), unique=True)
    starts_on: Mapped[date|None]=mapped_column(Date)
    ends_on: Mapped[date|None]=mapped_column(Date)
    is_active: Mapped[bool]=mapped_column(Boolean, default=True)

class Course(Base):
    __tablename__='courses'
    id: Mapped[int]=mapped_column(primary_key=True)
    code: Mapped[str]=mapped_column(String(20), unique=True)
    title: Mapped[str]=mapped_column(String(140), nullable=False)
    credit_hours: Mapped[int]=mapped_column(Integer, default=3)
    department_id: Mapped[int|None]=mapped_column(ForeignKey('departments.id', ondelete='SET NULL'))
    department=relationship('Department', back_populates='courses')

class CourseOffering(Base):
    __tablename__='course_offerings'
    id: Mapped[int]=mapped_column(primary_key=True)
    course_id: Mapped[int]=mapped_column(ForeignKey('courses.id', ondelete='CASCADE'))
    teacher_id: Mapped[int|None]=mapped_column(ForeignKey('teachers.id', ondelete='SET NULL'))
    session_id: Mapped[int|None]=mapped_column(ForeignKey('academic_sessions.id', ondelete='SET NULL'))
    section: Mapped[str]=mapped_column(String(30), default='A')
    course=relationship('Course')
    teacher=relationship('Teacher')
    session=relationship('AcademicSession')

class CourseRegistration(Base):
    __tablename__='course_registrations'
    __table_args__=(UniqueConstraint('student_id','offering_id',name='uq_student_offering'),)
    id: Mapped[int]=mapped_column(primary_key=True)
    student_id: Mapped[int]=mapped_column(ForeignKey('students.id', ondelete='CASCADE'))
    offering_id: Mapped[int]=mapped_column(ForeignKey('course_offerings.id', ondelete='CASCADE'))
    registered_on: Mapped[date]=mapped_column(Date, default=date.today)
    status: Mapped[str]=mapped_column(String(20), default='Enrolled')
    student=relationship('Student', back_populates='registrations')
    offering=relationship('CourseOffering')

class Attendance(Base):
    __tablename__='attendance'
    __table_args__=(UniqueConstraint('student_id','offering_id','attended_on',name='uq_attendance_day'),)
    id: Mapped[int]=mapped_column(primary_key=True)
    student_id: Mapped[int]=mapped_column(ForeignKey('students.id', ondelete='CASCADE'))
    offering_id: Mapped[int]=mapped_column(ForeignKey('course_offerings.id', ondelete='CASCADE'))
    attended_on: Mapped[date]=mapped_column(Date, default=date.today)
    status: Mapped[str]=mapped_column(String(15), default='Present')
    remarks: Mapped[str|None]=mapped_column(String(250))
    student=relationship('Student')
    offering=relationship('CourseOffering')

class Assessment(Base):
    __tablename__='assessments'
    id: Mapped[int]=mapped_column(primary_key=True)
    offering_id: Mapped[int]=mapped_column(ForeignKey('course_offerings.id', ondelete='CASCADE'))
    title: Mapped[str]=mapped_column(String(120))
    total_marks: Mapped[float]=mapped_column(Numeric(8,2))
    exam_date: Mapped[date|None]=mapped_column(Date)
    offering=relationship('CourseOffering')

class AssessmentResult(Base):
    __tablename__='assessment_results'
    __table_args__=(UniqueConstraint('assessment_id','student_id',name='uq_assessment_student'),)
    id: Mapped[int]=mapped_column(primary_key=True)
    assessment_id: Mapped[int]=mapped_column(ForeignKey('assessments.id', ondelete='CASCADE'))
    student_id: Mapped[int]=mapped_column(ForeignKey('students.id', ondelete='CASCADE'))
    obtained_marks: Mapped[float]=mapped_column(Numeric(8,2))
    grade: Mapped[str|None]=mapped_column(String(5))
    assessment=relationship('Assessment')
    student=relationship('Student')

class FeeInvoice(Base):
    __tablename__='fee_invoices'
    id: Mapped[int]=mapped_column(primary_key=True)
    student_id: Mapped[int]=mapped_column(ForeignKey('students.id', ondelete='CASCADE'))
    title: Mapped[str]=mapped_column(String(120), default='Tuition Fee')
    amount: Mapped[float]=mapped_column(Numeric(10,2))
    due_date: Mapped[date|None]=mapped_column(Date)
    status: Mapped[str]=mapped_column(String(20), default='Pending')
    student=relationship('Student')
    payments=relationship('Payment', back_populates='invoice')

class Payment(Base):
    __tablename__='payments'
    id: Mapped[int]=mapped_column(primary_key=True)
    invoice_id: Mapped[int]=mapped_column(ForeignKey('fee_invoices.id', ondelete='CASCADE'))
    amount: Mapped[float]=mapped_column(Numeric(10,2))
    paid_on: Mapped[date]=mapped_column(Date, default=date.today)
    method: Mapped[str]=mapped_column(String(30), default='Cash')
    reference: Mapped[str|None]=mapped_column(String(80))
    invoice=relationship('FeeInvoice', back_populates='payments')

class User(Base):
    __tablename__='users'
    id: Mapped[int]=mapped_column(primary_key=True)
    username: Mapped[str]=mapped_column(String(80), unique=True, index=True)
    password_hash: Mapped[str]=mapped_column(String(255))
    role: Mapped[str]=mapped_column(String(30), default='Admin')
    is_active: Mapped[bool]=mapped_column(Boolean, default=True)

# Additional entities from the academic/administrative design in the project report.
class Guardian(Base):
    __tablename__='guardians'
    id: Mapped[int]=mapped_column(primary_key=True)
    name: Mapped[str]=mapped_column(String(120), nullable=False)
    phone: Mapped[str]=mapped_column(String(30), nullable=False)
    email: Mapped[str|None]=mapped_column(String(160))
    links=relationship('StudentGuardian', back_populates='guardian')

class StudentGuardian(Base):
    __tablename__='student_guardians'
    __table_args__=(UniqueConstraint('student_id','guardian_id',name='uq_student_guardian'),)
    id: Mapped[int]=mapped_column(primary_key=True)
    student_id: Mapped[int]=mapped_column(ForeignKey('students.id',ondelete='CASCADE'))
    guardian_id: Mapped[int]=mapped_column(ForeignKey('guardians.id',ondelete='CASCADE'))
    relationship_type: Mapped[str]=mapped_column(String(40),default='Parent')
    student=relationship('Student')
    guardian=relationship('Guardian',back_populates='links')

class Grade(Base):
    __tablename__='grades'
    id: Mapped[int]=mapped_column(primary_key=True)
    title: Mapped[str]=mapped_column(String(80),unique=True)

class Section(Base):
    __tablename__='sections'
    id: Mapped[int]=mapped_column(primary_key=True)
    grade_id: Mapped[int]=mapped_column(ForeignKey('grades.id',ondelete='CASCADE'))
    name: Mapped[str]=mapped_column(String(30))
    grade=relationship('Grade')

class TeachingAssignment(Base):
    __tablename__='teaching_assignments'
    __table_args__=(UniqueConstraint('teacher_id','course_id','session_id',name='uq_teaching_assignment'),)
    id: Mapped[int]=mapped_column(primary_key=True)
    teacher_id: Mapped[int]=mapped_column(ForeignKey('teachers.id',ondelete='CASCADE'))
    course_id: Mapped[int]=mapped_column(ForeignKey('courses.id',ondelete='CASCADE'))
    session_id: Mapped[int|None]=mapped_column(ForeignKey('academic_sessions.id',ondelete='SET NULL'))
    teacher=relationship('Teacher')
    course=relationship('Course')
    session=relationship('AcademicSession')

class FeeStructure(Base):
    __tablename__='fee_structures'
    id: Mapped[int]=mapped_column(primary_key=True)
    title: Mapped[str]=mapped_column(String(120))
    amount: Mapped[float]=mapped_column(Numeric(10,2))
    program: Mapped[str|None]=mapped_column(String(100))
    is_active: Mapped[bool]=mapped_column(Boolean,default=True)

class InvoiceItem(Base):
    __tablename__='invoice_items'
    id: Mapped[int]=mapped_column(primary_key=True)
    invoice_id: Mapped[int]=mapped_column(ForeignKey('fee_invoices.id',ondelete='CASCADE'))
    description: Mapped[str]=mapped_column(String(160))
    amount: Mapped[float]=mapped_column(Numeric(10,2))
