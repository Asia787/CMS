from datetime import date
from pydantic import BaseModel, ConfigDict, EmailStr, Field, model_validator
from typing import Optional

class ORM(BaseModel): model_config=ConfigDict(from_attributes=True)
class DepartmentIn(BaseModel): name:str; code:str; description:Optional[str]=None
class DepartmentOut(DepartmentIn,ORM): id:int
class StudentIn(BaseModel):
    roll_number:str; name:str; father_name:Optional[str]=None; email:Optional[EmailStr]=None; phone:Optional[str]=None; date_of_birth:Optional[date]=None; department_id:Optional[int]=None; program:Optional[str]=None; status:str='Active'
class StudentOut(StudentIn,ORM): id:int
class TeacherIn(BaseModel): name:str; email:Optional[EmailStr]=None; phone:Optional[str]=None; designation:Optional[str]=None; department_id:Optional[int]=None
class TeacherOut(TeacherIn,ORM): id:int
class SessionIn(BaseModel): title:str; starts_on:Optional[date]=None; ends_on:Optional[date]=None; is_active:bool=True
class SessionOut(SessionIn,ORM): id:int
class CourseIn(BaseModel): code:str; title:str; credit_hours:int=Field(default=3,ge=1,le=6); department_id:Optional[int]=None
class CourseOut(CourseIn,ORM): id:int
class OfferingIn(BaseModel): course_id:int; teacher_id:Optional[int]=None; session_id:Optional[int]=None; section:str='A'
class OfferingOut(OfferingIn,ORM): id:int
class RegistrationIn(BaseModel): student_id:int; offering_id:int; registered_on:date=date.today(); status:str='Enrolled'
class RegistrationOut(RegistrationIn,ORM): id:int
class AttendanceIn(BaseModel): student_id:int; offering_id:int; attended_on:date=date.today(); status:str='Present'; remarks:Optional[str]=None
class AttendanceOut(AttendanceIn,ORM): id:int
class AssessmentIn(BaseModel): offering_id:int; title:str; total_marks:float=Field(gt=0); exam_date:Optional[date]=None
class AssessmentOut(AssessmentIn,ORM): id:int
class ResultIn(BaseModel): assessment_id:int; student_id:int; obtained_marks:float=Field(ge=0); grade:Optional[str]=None
class ResultOut(ResultIn,ORM): id:int
class InvoiceIn(BaseModel): student_id:int; title:str='Tuition Fee'; amount:float=Field(gt=0); due_date:Optional[date]=None; status:str='Pending'
class InvoiceOut(InvoiceIn,ORM): id:int
class PaymentIn(BaseModel): invoice_id:int; amount:float=Field(gt=0); paid_on:date=date.today(); method:str='Cash'; reference:Optional[str]=None
class PaymentOut(PaymentIn,ORM): id:int
class LoginIn(BaseModel): username:str; password:str
class UserCreate(BaseModel): username:str; password:str=Field(min_length=8); role:str='Staff'
class UserOut(ORM): id:int; username:str; role:str; is_active:bool

class GuardianIn(BaseModel): name:str; phone:str; email:Optional[EmailStr]=None
class GuardianOut(GuardianIn,ORM): id:int
class StudentGuardianIn(BaseModel): student_id:int; guardian_id:int; relationship_type:str='Parent'
class StudentGuardianOut(StudentGuardianIn,ORM): id:int
class GradeIn(BaseModel): title:str
class GradeOut(GradeIn,ORM): id:int
class SectionIn(BaseModel): grade_id:int; name:str
class SectionOut(SectionIn,ORM): id:int
class TeachingAssignmentIn(BaseModel): teacher_id:int; course_id:int; session_id:Optional[int]=None
class TeachingAssignmentOut(TeachingAssignmentIn,ORM): id:int
class FeeStructureIn(BaseModel): title:str; amount:float=Field(gt=0); program:Optional[str]=None; is_active:bool=True
class FeeStructureOut(FeeStructureIn,ORM): id:int
class InvoiceItemIn(BaseModel): invoice_id:int; description:str; amount:float=Field(gt=0)
class InvoiceItemOut(InvoiceItemIn,ORM): id:int
